## The IAGOS ASCII files start with a useful descriptive header,
## but it can behave as a source of bugs when read with Fortran.
## Furthermore, the size of the header changes from one version to another,
## and the best would be that the bulk of the Fortran routine (interpol_iagos_2.f90)
## does not have to be modified manually, considering the IAGOS file version.
## Unfortunately, the data are not stored in the same column order between the two versions,
## and the Fortran routine has been modified manually for the new version.
## Still, the modification of the header options can be easily automatized.
## This script thus aims at removing the headers in each IAGOS file.
## Please just precise the amount of lines that constitute the header.
nlines_header=75
## --> I recently noticed that the header could change from one file to another.
## Fortunately, the amount of data in each file is precized in the header.
## Thus we just have to read the corresponding row.

########## 1/ Main commands ##########

### Start and end of the dataset.
### Please note that the IAGOS measurements start in Aug. 1994.
yyyymm1=201701 ; yyyymm2=201712

### The directory where the initial IAGOS data are stored.
input_iagos_data_dir=~/Pack_code/data/IAGOS_database/ASCII/txt_IAGOS_with_headers
output_iagos_data_dir=~/Pack_code/data/IAGOS_database/ASCII/txt_IAGOS_without_headers
output_iagos_column_names_dir=~/Pack_code/data/IAGOS_database/ASCII/txt_IAGOS_column_names
### Lists of the IAGOS files to be read. There is one list per month.
list_iagos_dir=${input_iagos_data_dir}/lists_iagos_files
mkdir -p $output_iagos_data_dir
mkdir -p $output_iagos_column_names_dir


echo -e "\e[00;37m==============================================\e[00m"
echo -e "\e[00;37m==================== START  ==================\e[00m"
echo -e "\e[00;37m==============================================\e[00m"

###  Here a chrono starts, in order to compute how much time the routine runs.
function convertsec(){ # Convert seconds (for chrono routines...)
    echo $(($1 / 86400))':'`date +%H:%M:%S -d "0000-01-01 $(($1 % 86400)) seconds"`
}
debut=`date +%s`

### Creating the lists of IAGOS directories.
if [ $((ls $input_iagos_data_dir | grep "list_iagos_files") | wc -l) -eq 0 ] ; then
    mkdir $list_iagos_dir
fi

### quicktest=1 is just an option to test the script.
### The script will only read the first IAGOS file indicated in each monthly list. Despite it is a fast test, it spreads over the whole period.
quicktest=0
#### Computes the amounts of horizontal grid points.

#### Generates the list of months from yyyymm1 to yyyymm2.
yyyymm=$yyyymm1
listmonths=$yyyymm
nmonths=1
while [ $yyyymm -lt $yyyymm2 ] ; do
    yyyymm=`date -d "${yyyymm}01 1 months" +%Y%m`
    listmonths=${listmonths}" "${yyyymm}
    nmonths=$((nmonths+1))
done

yyyy1=${yyyymm1:0:4} ; yyyy2=${yyyymm2:0:4}
yyyy=$yyyy1
listyears=$yyyy
while [ $yyyy -lt $yyyy2 ] ; do
    yyyy=`date -d "${yyyy}0101 1 years" +%Y`
    listyears=${listyears}" "${yyyy}
done

reinitialize_list_files=1
if [ $reinitialize_list_files -eq 1 ] ; then
    rm -rf $list_iagos_dir
    mkdir $list_iagos_dir
    for yyyy in $listyears ; do
	mkdir ${list_iagos_dir}/$yyyy
    done
fi

#### 1/ Month by month, lists the corresponding IAGOS files and stocks the list into a file.
#### 2/ Also counts the amount of IAGOS files for each month.
for yyyymm in $listmonths ; do
    # 1/
    yyyy=${yyyymm:0:4}
    month_dir=${input_iagos_data_dir}/${yyyy}/${yyyymm}
    listing_file=${list_iagos_dir}/${yyyy}/list_${yyyymm}
    if [ $quicktest -eq 1 ] ; then # Just picks one file to accelerate the tests
	list_iagos_files=$(ls $month_dir | head -1)
	echo ${list_iagos_files} > ${listing_file}
	nfiles=1
    else
	if [ $reinitialize_list_files -eq 1 ] ; then
	    ls ${month_dir} > ${listing_file}
	fi
	nfiles=$(ls ${month_dir} | wc -l)	
    fi
    # 2/
    if [ $yyyymm -eq $yyyymm1 ] ; then
	list_nfiles=$nfiles
    else
	list_nfiles=${list_nfiles}" "${nfiles}
    fi
done
echo -e "\e[00;31m Lists of IAGOS files generated in \e[00m" ${list_iagos_dir}

#### 3/ For each IAGOS file, copies the data only into a temporary file.
echo -e "\e[00;31m Copying the data without the header in \e[00m" ${output_iagos_data_dir}
for yyyymm in $listmonths ; do
    yyyy=${yyyymm:0:4}
    outdir_yyyymm=${output_iagos_data_dir}/${yyyy}/$yyyymm
    outdir_column_names_yyyymm=${output_iagos_column_names_dir}/${yyyy}/$yyyymm
    mkdir -p ${output_iagos_data_dir}/${yyyy}
    mkdir -p $outdir_yyyymm
    mkdir -p ${output_iagos_column_names_dir}/${yyyy}
    mkdir -p $outdir_column_names_yyyymm
    listing_file=${list_iagos_dir}/${yyyy}/list_${yyyymm}
    for filename in $(cat $listing_file) ; do
	echo 'file = '$filename
	file_path=${input_iagos_data_dir}/${yyyy}/${yyyymm}/$filename ### input file
	nlines_data_only=$(grep number_observations $file_path | cut -d' ' -f2)
	echo -e "\e[00;35m | $nlines_data_only data \e[00m"
	##### Extracting the data only.
	out_file=${outdir_yyyymm}/$filename
	tail -$nlines_data_only $file_path > $out_file
	##### Now, the same with the column names (last line from the header).
	nlines_tot=$(cat $file_path | wc -l)
	iline_list_columns=$((nlines_tot-nlines_data_only))
	out_file=${outdir_column_names_yyyymm}/$filename
	head -${iline_list_columns} $file_path | tail -1 > $out_file
	##### Last, since memory is precious: delete the original file (data+header).
	rm $file_path
    done
done
#(Here stops the chrono)
fin=`date +%s`
temps_ecoule=`convertsec $(($fin-$debut))`  #(copy the convertsec function in my ~/.bashrc to yours)
echo -e "\e[00;31m |   END OF TRE PROGRAM   \e[00m  (duration : ${temps_ecoule})"
echo -e "\e[00;31m |   New IAGOS files available in  \e[00m"${output_iagos_data_dir}
echo -e "\e[00;31m |   and its list of column names in  \e[00m"${output_iagos_data_dir}
