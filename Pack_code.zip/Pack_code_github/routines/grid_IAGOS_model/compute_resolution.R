args = commandArgs(trailingOnly=TRUE)

nlon     =as.integer(args[1])
nlat     =as.integer(args[2])
lon_dom_1=as.numeric(args[3])
lon_dom_2=as.numeric(args[4])
lat_dom_1=as.numeric(args[5])
lat_dom_2=as.numeric(args[6])
outfile  =args[7]

## Deriving the horizontal resolution.
lon_resol=(lon_dom_2-lon_dom_1)/nlon
lat_resol=round((lat_dom_2-lat_dom_1)/nlat,digits=6)
## Deriving the domain boundaries, in terms of gridcell coordinates. Since lon_dom_2 and lat_dom_2 refer to East/North cell limits whereas we chose to locate the gridcells with their Southwest corner, we have to define the domain boundaries as the coordinates of the last gridcell. Example for MOCAGE REFC1SD experiment: lon1=-180°E but lon2=178°E instead of 180°E.
lon1=lon_dom_1
lon2=lon_dom_2-lon_resol
lat1=lat_dom_1
lat2=lat_dom_2-lat_resol
mytext=paste(lon_resol,lat_resol,lon1,lon2,lat1,lat2)

con <- file(outfile,open="w")
writeLines(mytext, con = con)
close(con)
