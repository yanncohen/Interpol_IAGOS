#!/bin/bash

output_tmp_file=./tmp/current_IAGOS_file_characteristics.txt
## 1/ Data table dimensions.
column_names_file=$(head -1 ./tmp/filepath.txt)
data_file=$(tail -1 ./tmp/filepath.txt)
ncolumns=0
for var_col in $(cat $column_names_file) ; do
    ncolumns=$((ncolumns+1))
done
nlines=$(cat $data_file | wc -l)
echo $ncolumns > $output_tmp_file
echo $nlines >> $output_tmp_file
## 2/ Finding which Package it is by reading the name of the O3 variable.
## This is necessary because the variable names change with the package.
## 2.1/ Searching the O3 variable.
var_O3=NONE
for var_col in $(cat $column_names_file) ; do
    if [ ${var_col:0:2} = "O3" ] && [ $var_O3 = NONE ] ; then
	var_O3=$var_col
    fi
done

## 2.2/ Deducing the appropriate column in the reference file.
case $var_O3 in
    'O3_PM') ## MOZAIC file
	appropriate_column=2
	;;
    'O3_P1') ## IAGOS-Core file
	appropriate_column=3
	;;
    'O3_PC1') ## CARIBIC file
	appropriate_column=4
	;;
    'O3_PC2') ## IAGOS-CARIBIC file
	appropriate_column=5
	;;
esac
list_coord_names=$(cat namelist_extract | grep 'UTC')
list_var_names=$(cat namelist_extract | grep 'Ozone')
## 2.3/ Reading the appropriate names for each variable queried by the user.
## The question is: under what name do we have to look the variables for?
## By the way, excludes the variables that cannot be found in the current file
## because non existent in the current package.
var_list=""
for var_coord in $list_coord_names ; do
    var=$(cat variable_names_in_IAGOS_files.txt | grep $var_coord | awk -v icol=$appropriate_column '{print $icol}')
    var_list=${var_list}' '$var
done
for var_user in $list_var_names ; do
    var=$(cat variable_names_in_IAGOS_files.txt | grep $var_user | awk -v icol=$appropriate_column '{print $icol}')
    if [ $var != NONE ] ; then
	var_list=${var_list}' '$var
    fi
done
# echo $var_list
## 3/ Last: finding the column index for each variable.
## Necessarily repeated for each file, because many variables are not present in all IAGOS files.
##### Initialization #####
icol=0
var_icol=not_known_yet
# list_column_indexes=$icol
list_column_indexes=""
# final_var_list=$var_icol
final_var_list=""
final_var_list_fullnames=""
ncolumns_list=0
###########################
for var in $var_list ; do
    while [ $var_icol != $var ] && [ $icol -lt $ncolumns ] ; do
	icol=$((icol+1))
	var_icol=$(cat $column_names_file | awk -v icol=$icol '{print $icol}')
	# echo $icol $var_icol $var
    done
    if [ $var_icol = $var ] ; then
	ncolumns_list=$((ncolumns_list+1))
	list_column_indexes=${list_column_indexes}" "$icol
	## Names into the IAGOS data file.
	final_var_list=${final_var_list}" "$var_icol
	## Full names, as those written in the make file.
	var_fullname=$(cat variable_names_in_IAGOS_files.txt | grep -E -w ${var} | awk '{print $1}')
	final_var_list_fullnames=${final_var_list_fullnames}' '$var_fullname
	# var_fullname_icol=$(cat $column_names_file | awk '{print $1}')
	# final_var_list_fullnames=${final_var_list_fullnames}" "
    fi
    ## Reinitialization.
    icol=0
    var_icol=not_known_yet
done
echo $ncolumns_list >> $output_tmp_file
echo $list_column_indexes >> $output_tmp_file
echo $final_var_list_fullnames >> $output_tmp_file
